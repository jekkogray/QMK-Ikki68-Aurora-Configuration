/* This file was automatically generated. Do not edit or copy.
 */

#pragma once

#define QMK_VERSION "fa1a59-dirty"
#define QMK_BUILDDATE "2021-10-10-21:16:51"
#define CHIBIOS_VERSION "2021-10-10-21:16:51"
#define CHIBIOS_CONTRIB_VERSION "2021-10-10-21:16:51"
