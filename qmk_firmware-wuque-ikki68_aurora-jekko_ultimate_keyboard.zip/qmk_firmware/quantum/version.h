/* This file was automatically generated. Do not edit or copy.
 */

#pragma once

#define QMK_VERSION "ee9da1-dirty"
#define QMK_BUILDDATE "2021-10-10-05:26:53"
#define CHIBIOS_VERSION "2021-10-10-05:26:53"
#define CHIBIOS_CONTRIB_VERSION "2021-10-10-05:26:53"
